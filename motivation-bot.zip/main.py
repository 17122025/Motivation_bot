import telebot
import datetime
import time

TOKEN = "YOUR_BOT_TOKEN"
bot = telebot.TeleBot(TOKEN)

# Массив мотивационных фраз
motivations = [
    "Ты сильнее, чем думаешь 💪",
    "Каждый шаг приближает тебя к цели 🚶‍♀️🚶‍♂️",
    "Не сдавайся — ты уже так много прошла!",
    "Мечта работает, только если работаешь ты 💼",
    "Даже маленький шаг — это шаг вперёд 👣"
]

@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id, "Привет! Я твой мотивационный бот! ❤️
Я помогу тебе добиться цели!")

@bot.message_handler(commands=['motivate'])
def send_motivation(message):
    import random
    quote = random.choice(motivations)
    bot.send_message(message.chat.id, quote)

print("Бот запущен...")
bot.polling()
